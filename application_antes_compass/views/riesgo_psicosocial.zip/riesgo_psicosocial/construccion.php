<div class="jumbotron">
	<div class="container">
		<div class="page-header ">
		<h1 class="text-center">Módulo en construcción <i class="fa fa-wrench"></i></h1>
		<p>&nbsp;</p>
		<h1 class="text-center"><small>SONDA Diagnóstico de clima organizacional</small></h1>
		<p>&nbsp;</p>
			<div class="progress progress-striped active">
					<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;"></div>
				</div>
		</div>
	</div>
</div>